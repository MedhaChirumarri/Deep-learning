#data2 99.5 , 100

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.mixture import GaussianMixture


def standardization(data):
    scaler = StandardScaler()
    scaler = scaler.fit(data)
    return scaler.transform(data)


def percentage_accuracy(y_true, y_pred):
    return accuracy_score(y_true, y_pred)*100

def confusion_matrix_(y_true,y_pred):
    return confusion_matrix(y_true, y_pred)

df1 = pd.read_csv("/content/Class1.txt",sep="\t", header=None, names=["x","y","rn"])
df2 = pd.read_csv("/content/Class2.txt",sep="\t", header=None, names=["x","y","rn"])
train = df1.append(df2)
train = train.drop(['rn'], axis=1)
train = pd.DataFrame(standardization(train))

labels1 = [0]*len(df1)
labels2 = [1]*len(df2)
labels = labels1 + labels2
test = np.array(labels)
train["class"] = test
test = train["class"]



X_train, X_test, y_train, y_test = train_test_split(train,test, test_size=0.30, random_state=42)
df = X_train.groupby('class')

#class0
data0 = pd.DataFrame(df.get_group(0))
data0 = data0.drop('class',axis=1)

#class1
data1 = df.get_group(1)
data1 = data1.drop('class',axis=1)

X_test = X_test.drop('class',axis=1)


acc = []
q = [1,2,3,4,5,6,7,8,9,10]
for i in q:
    y_pred = []
    gmm1 = GaussianMixture(n_components=i)
    g1 = gmm1.fit(data0)
    p1 = g1.score_samples(X_test)
    gmm2 = GaussianMixture(n_components=i)
    g2 = gmm2.fit(data1)
    p2 = g2.score_samples(X_test)
    for j in range(len(p1)):
        if(p1[j]>p2[j]):
            y_pred.append(0)
        else:
            y_pred.append(1)
    print("for",i)
    print("Confusion Matrix")
    print(confusion_matrix_(y_test,y_pred))
    print("Percentage Accuracy ", percentage_accuracy(y_test, y_pred),"%")
    print(" ")
    acc.append(percentage_accuracy(y_test, y_pred))
plt.plot(q,acc)
plt.show()






#data1 98.0 , 100





import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.mixture import GaussianMixture


def standardization(data):
    scaler = StandardScaler()
    scaler = scaler.fit(data)
    return scaler.transform(data)


def percentage_accuracy(y_true, y_pred):
    return accuracy_score(y_true, y_pred)*100

def confusion_matrix_(y_true,y_pred):
    return confusion_matrix(y_true, y_pred)

df1 = pd.read_csv("/content/Class1.txt",sep=",", header=None, names=["x","y","rn"])
df2 = pd.read_csv("/content/Class2.txt",sep=",", header=None, names=["x","y","rn"])
train = df1.append(df2)
train = train.drop(['rn'], axis=1)
train = pd.DataFrame(standardization(train))

labels1 = [0]*len(df1)
labels2 = [1]*len(df2)
labels = labels1 + labels2
test = np.array(labels)
train["class"] = test
test = train["class"]



X_train, X_test, y_train, y_test = train_test_split(train,test, test_size=0.30, random_state=42)
df = X_train.groupby('class')

#class0
data0 = pd.DataFrame(df.get_group(0))
data0 = data0.drop('class',axis=1)

#class1
data1 = df.get_group(1)
data1 = data1.drop('class',axis=1)

X_test = X_test.drop('class',axis=1)


acc = []
q = [1,2,3,4,5,6,7,8,9,10]
for i in q:
    y_pred = []
    gmm1 = GaussianMixture(n_components=i)
    g1 = gmm1.fit(data0)
    p1 = g1.score_samples(X_test)
    gmm2 = GaussianMixture(n_components=i)
    g2 = gmm2.fit(data1)
    p2 = g2.score_samples(X_test)
    for j in range(len(p1)):
        if(p1[j]>p2[j]):
            y_pred.append(0)
        else:
            y_pred.append(1)
    print("for",i)
    print("Confusion Matrix")
    print(confusion_matrix_(y_test,y_pred))
    print("Percentage Accuracy ", percentage_accuracy(y_test, y_pred),"%")
    print(" ")
    acc.append(percentage_accuracy(y_test, y_pred))
plt.plot(q,acc)
plt.show()

