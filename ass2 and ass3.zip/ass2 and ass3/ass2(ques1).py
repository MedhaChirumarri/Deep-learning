import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import copy
from sklearn.metrics import accuracy_score
pd.options.mode.chained_assignment = None


def percentage_accuracy(y_true, y_pred):
    return accuracy_score(y_true, y_pred)*100


df1 = pd.read_csv("/content/Class1.txt",sep="\t", header=None, names=["x","y","rn"])
df2 = pd.read_csv("/content/Class2.txt",sep="\t", header=None, names=["x","y","rn"])
train = df1.append(df2)
train = train.drop(['rn'], axis=1)

labels1 = [0]*len(df1)
labels2 = [1]*len(df2)
labels = labels1 + labels2
test = np.array(labels)
train["class"] = test
test = train["class"]

train = train.drop(['class'], axis=1)
X_train, X_test, y_train, y_test = train_test_split(train,test, test_size=0.30, random_state=42)
x = X_train["x"]
y = X_train["y"]
df = X_train

colmap = {1: 'r', 2: 'b'}
np.random.seed(200)
k = 2
centroids = {
    i+1 : [np.random.randint(min(x),max(x)), np.random.randint(min(y),max(y))]
    for i in range(k)
}


def assignment(df, centroids):
    for i in centroids.keys():
        df['distance_from_{}'.format(i)] = (
            np.sqrt(
                (df['x'] - centroids[i][0]) ** 2
                + (df['y'] - centroids[i][1]) ** 2
            )
        )
    centroid_distance_cols = ['distance_from_{}'.format(i) for i in centroids.keys()]
    df['closest'] = df.loc[:, centroid_distance_cols].idxmin(axis=1)
    df['closest'] = df['closest'].map(lambda x: int(x.lstrip('distance_from_')))
    df['color'] = df['closest'].map(lambda x: colmap[x])
    return df

df = assignment(df, centroids)


def update(k):
    for i in centroids.keys():
        centroids[i][0] = np.mean(df[df['closest'] == i]['x'])
        centroids[i][1] = np.mean(df[df['closest'] == i]['y'])
    return k


while True:
    closest_centroids = df['closest'].copy(deep=True)
    centroids = update(centroids)
    df = assignment(df, centroids)
    if closest_centroids.equals(df['closest']):
        break

    fig = plt.figure(figsize=(5, 5))
    plt.scatter(df['x'], df['y'], color=df['color'], alpha=0.5, edgecolor='k')
    for i in centroids.keys():
        plt.scatter(*centroids[i], color=colmap[i])
    plt.xlim(-20, 40)
    plt.ylim(-20, 40)
    plt.show()

count0 = 0
count1 = 0
for i,j in zip(df["closest"],y_train):
  if(i == 1 and j == 0):
    count0 = count0 + 1
  if(i == 1 and j == 1):
    count1 = count1 + 1


df1 = assignment(X_test, centroids)

map1 = {1: 0, 2: 1}
map2 = {1: 1, 2: 0}
if(count0 >= count1):
  df1["closest"] = df1['closest'].map(lambda x: map1[x])
else:
  df1["closest"] = df1['closest'].map(lambda x: map2[x])


y_pred = (df1["closest"]).to_numpy()
y_true = (y_test).to_numpy()
print(percentage_accuracy(y_test, y_pred))


