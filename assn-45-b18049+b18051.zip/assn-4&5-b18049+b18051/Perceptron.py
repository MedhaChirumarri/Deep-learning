import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt


def split(path1,path2):
    df1 = pd.read_csv(path1,sep="\t", header=None, names=["x","y","rn"])
    df2 = pd.read_csv(path2,sep="\t", header=None, names=["x","y","rn"])
    train = df1.append(df2)
    train = train.drop(['rn'], axis=1)

    labels1 = [0]*len(df1)
    labels2 = [1]*len(df2)
    labels = labels1 + labels2
    test = np.array(labels)
    train["class"] = test
    test = train["class"]

    X_train, X_test, Y_train, Y_test = train_test_split(train,test, test_size=0.30, random_state=42)
    X_test = X_test.drop('class',axis=1)
    X_train = X_train.drop('class',axis=1)

    return X_train, X_test, Y_train, Y_test

class Perceptron:
  
  def __init__ (self):
    self.w = None
    self.b = None
    
  def model(self, x):
    return 1 if (np.dot(self.w, x) >= self.b) else 0
    
  def predict(self, X):
    Y = []
    for x in X:
      result = self.model(x)
      Y.append(result)
    return np.array(Y)
    
  def fit(self, X, Y, epochs = 1, lr = 1):
    
    self.w = np.ones(X.shape[1])
    self.b = 0
    
    accuracy = {}
    max_accuracy = 0
    
    wt_matrix = []
    
    for i in range(epochs):
      for x, y in zip(X, Y):
        y_pred = self.model(x)
        if y == 1 and y_pred == 0:
          self.w = self.w + lr * x
          self.b = self.b - lr * 1
        elif y == 0 and y_pred == 1:
          self.w = self.w - lr * x
          self.b = self.b + lr * 1
          
      wt_matrix.append(self.w)    
          
      accuracy[i] = accuracy_score(self.predict(X), Y)
      if (accuracy[i] > max_accuracy):
        max_accuracy = accuracy[i]
        chkptw = self.w
        chkptb = self.b
        
    self.w = chkptw
    self.b = chkptb
        
    print(max_accuracy)
    
    plt.plot(np.array(list(accuracy.values())).astype(float))
    plt.ylim([0, 1.5])
    plt.show()
    
    return np.array(wt_matrix)

X_train, X_test, Y_train, Y_test = split("/content/linear/Class1.txt","/content/linear/Class2.txt")
print("for linearly seperable data")
X_train = X_train.values
X_test = X_test.values
perceptron = Perceptron()
wt_matrix = perceptron.fit(X_train, Y_train, 1000, 0.5)
Y_pred_test = perceptron.predict(X_test)
print(accuracy_score(Y_pred_test, Y_test))

print(" ")

X_train, X_test, Y_train, Y_test = split("/content/nonlinear/Class1.txt","/content/nonlinear/Class2.txt")
print("for nonlinearly seperable data")
X_train = X_train.values
X_test = X_test.values
perceptron = Perceptron()
wt_matrix = perceptron.fit(X_train, Y_train, 1000, 0.5)
Y_pred_test = perceptron.predict(X_test)
print(accuracy_score(Y_pred_test, Y_test))
