#reading files
import zipfile
with zipfile.ZipFile("/content/0.zip","r") as zip_ref:
    zip_ref.extractall("/content/zero")
with zipfile.ZipFile("/content/testSample.zip","r") as zip:
    zip.extractall("/content/test")

import glob
images=[]
images.append(glob.glob("/content/zero/0/img_*.jpg"))
test=[]
test.append(glob.glob("/content/test/testSample/img_*.jpg"))

import cv2
import matplotlib.pyplot as plt
import glob
img_1d=[]
tt=[]
for i in images[0]:
  img = cv2.imread(i) 
  image=img.flatten()
  img_1d.append(image)
for i in test[0]:
  img = cv2.imread(i) 
  image=img.flatten()
  tt.append(image)
print(img.shape)
print(len(images[0]))

#standard scaler for data
from sklearn.preprocessing import StandardScaler
import pandas as pd
x_train=pd.DataFrame(img_1d)
x_test=pd.DataFrame(tt)
sc = StandardScaler()
x_train=sc.fit_transform(x_train)
x_test=sc.transform(x_test)

#performing pca
from sklearn.decomposition import PCA
pca = PCA(n_components=28, svd_solver='randomized',whiten=True)
x_train = pca.fit_transform(x_train)
x_test=pca.transform(x_test)

#eigen vectors and eigen values
eigenvalues = pca.explained_variance_
print(eigenvalues)
eigenvectors=(pca.components_)
print(eigenvectors)


#reconstructing the images
X_inv = pca.inverse_transform(x_test)

X_proj_img = np.reshape(X_inv,(350,28,28,3))
#print(X_proj_img)

fig = plt.figure(figsize=(6,6)) 
fig.subplots_adjust(left=0, right=1, bottom=0, top=1, hspace=0.05, wspace=0.05)

for i in range(10): 
  ax = fig.add_subplot(2,5, i+1, xticks=[], yticks=[])
  ax.imshow(X_proj_img[i], cmap=plt.cm.bone, interpolation='nearest') 


#code for pca from stratch-but couldnt reconstruct the data
x_train=pd.DataFrame(img_1d)
from sklearn.preprocessing import StandardScaler
x_train = StandardScaler().fit_transform(x_train)
x_train= x_train - np.mean(x_train , axis = 0)
features = x_train.T
cov_matrix = np.cov(features)
values, vectors = np.linalg.eig(cov_matrix)
explained_variances = []
for i in range(len(values)):
    explained_variances.append(values[i] / np.sum(values))
sorted_index = np.argsort(values)[::-1]
sorted_eigenvalue = values[sorted_index]
sorted_eigenvectors =vectors[:,sorted_index]
     
print(sorted_eigenvalue)
print(sorted_eigenvectors)
eigenvector_subset = sorted_eigenvectors[:,0:2352]
     
X_reduced = np.dot(eigenvector_subset.transpose() , x_train.transpose() ).transpose()

X_proj_img = np.reshape(X_reduced,(60,28,28,3))
#print(X_proj_img)
np.array(X_proj_img[:, 1], dtype=np.float)
#fig = plt.figure(figsize=(6,6)) 
#fig.subplots_adjust(left=0, right=1, bottom=0, top=1, hspace=0.05, wspace=0.05)

#for i in range(10): 
 # ax = fig.add_subplot(2,5, i+1, xticks=[], yticks=[])
  #ax.imshow(X_proj_img[i], cmap=plt.cm.bone, interpolation='nearest')

#adding noise
import cv2
import matplotlib.pyplot as plt
import glob
img_1d_noise=[]
for i in images[0]:
  img = cv2.imread(i) #you can use any image you want.
  gauss = np.random.normal(0,0.15,img.size)
  gauss = gauss.reshape(img.shape[0],img.shape[1],img.shape[2]).astype('uint8')
# Add the Gaussian noise to the image
  img_gauss = cv2.add(img,gauss)
  image=img_gauss.flatten()
  img_1d_noise.append(image)
plt.imshow(img_gauss)
#print(img.shape)
#print(image.shape)
print(len(images[0]))


